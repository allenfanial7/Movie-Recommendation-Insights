def genre_analysis(movies, ratings):
    merged = ratings.merge(movies, on="movieId")
    genre_ratings = merged.groupby("genres")["rating"].mean().sort_values(ascending=False)
    return genre_ratings