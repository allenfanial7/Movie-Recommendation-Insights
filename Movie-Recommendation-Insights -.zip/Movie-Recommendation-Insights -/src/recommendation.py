def recommend_movies(movies, ratings, min_ratings=500):
    movie_stats = ratings.groupby("movieId").agg(
        avg_rating=("rating", "mean"),
        count=("rating", "count")
    )
    popular = movie_stats[movie_stats['count'] > min_ratings]
    top_movies = popular.sort_values("avg_rating", ascending=False)
    return movies.merge(top_movies, on="movieId").head(10)