import pandas as pd
import os

def load_data():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_path = os.path.join(base_dir, "data")

    movies = pd.read_csv(os.path.join(data_path, "movie.csv"))
    ratings = pd.read_csv(os.path.join(data_path, "rating.csv"))

    return movies, ratings