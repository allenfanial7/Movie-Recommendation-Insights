def clean_data(movies, ratings):
    ratings.dropna(inplace=True)
    movies['genres'] = movies['genres'].str.replace('|', ', ')
    return movies, ratings