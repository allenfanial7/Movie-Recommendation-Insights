import matplotlib.pyplot as plt

def plot_top_genres(genre_ratings):
    top = genre_ratings.head(10)
    top.plot(kind='bar', figsize=(10,5))
    plt.title("Top Rated Genres")
    plt.ylabel("Average Rating")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig("output/charts/top_genres.png")
    plt.show()