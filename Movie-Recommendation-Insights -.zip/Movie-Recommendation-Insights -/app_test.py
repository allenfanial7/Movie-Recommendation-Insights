import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import plotly.express as px
import os

st.set_page_config(page_title="Movie Recommendation Insights", layout="wide")
st.title("🎬 Movie Recommendation Insights")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")

movies = pd.read_csv(os.path.join(DATA_DIR, "movie.csv"))
ratings = pd.read_csv(os.path.join(DATA_DIR, "rating.csv"))

# ===============================
# 🔥 FORCE SINGLE GENRE (FINAL)
# ===============================
movies["genre_single"] = movies["genres"].astype(str).str.split("|").str[0]

merged = ratings.merge(movies, on="movieId")

genre_stats = merged.groupby("genre_single").agg(
    avg_rating=("rating", "mean"),
    rating_count=("rating", "count")
).reset_index()

# ===============================
# ⭐ TOP RATED GENRES
# ===============================
st.subheader("⭐ Top Rated Genres")

top_rated = genre_stats.sort_values("avg_rating", ascending=True).tail(6)

fig, ax = plt.subplots(figsize=(12, 4))
ax.barh(top_rated["genre_single"], top_rated["avg_rating"])
ax.set_xlabel("Average Rating")
ax.set_ylabel("Genre")
ax.set_title("Top Rated Genres")

st.pyplot(fig)

# ===============================
# 📊 GENRE POPULARITY
# ===============================
st.subheader("📊 Animated Genre Popularity")

popular = genre_stats.sort_values("rating_count", ascending=True).tail(6)

fig2 = px.bar(
    popular,
    x="rating_count",
    y="genre_single",
    orientation="h",
    title="Genre Popularity"
)

st.plotly_chart(fig2, use_container_width=True)