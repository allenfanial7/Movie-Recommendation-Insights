Movie Recommendation Insights
- Genre analysis
- Rating trends
- Popular movie detection
- Recommendation system