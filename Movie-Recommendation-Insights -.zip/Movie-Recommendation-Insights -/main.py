from src.data_loader import load_data
from src.data_cleaning import clean_data
from src.analysis import genre_analysis
from src.visualization import plot_top_genres
from src.recommendation import recommend_movies

movies, ratings = load_data()
movies, ratings = clean_data(movies, ratings)

genre_ratings = genre_analysis(movies, ratings)
plot_top_genres(genre_ratings)

recommendations = recommend_movies(movies, ratings)
print("\nTop Recommended movie:\n")
print(recommendations[['title', 'avg_rating']])